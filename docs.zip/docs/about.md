---
title: "About Me"
permalink: /about/
---

I design secure backend services that help teams ship faster with confidence.  
I’m looking for a role as a **Security Engineer** in a collaborative, growth-oriented team.

### Interests

-   Threat modeling
-   Incident response
-   API security
