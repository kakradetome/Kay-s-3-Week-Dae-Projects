---
layout: splash
title: "Your Name"
subtitle: "Cybersecurity & Backend Development"
---

<img src="/assets/img/pinky.jpg" alt="Headshot" width="200" style="border-radius:50%;" />

Welcome! I’m **Your Name**, a cybersecurity and backend developer passionate about building secure, reliable systems.

**Full Name:** Your Name  
**Graduation Date:** Dec 2025

![dae logo](/assets/img/dae-logo.avif){: style="width:120px;" }
