---
title: "Resume"
permalink: /resume/
---

## Education

Cybersecurity & Backend Development — dae  
**Expected Graduation:** Dec 2025

## Skills

-   Python, Go, TypeScript
-   AWS, Azure
-   Docker, Kubernetes
