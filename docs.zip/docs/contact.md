---
title: "Contact"
permalink: /contact/
---

-   Email: [you@example.com](mailto:you@example.com)
-   LinkedIn: [linkedin.com/in/your-profile](https://linkedin.com/in/your-profile)
-   GitHub: [github.com/your-username](https://github.com/your-username)
