---
title: "Projects"
permalink: /projects/
---

## Secure File Storage System

**Problem:** Sensitive files stored without encryption.  
**Solution:** Client-side encryption + RBAC.  
**Outcome:** 0 critical misconfigurations in 90 days.

<img src="/assets/img/dae-logo.png" width="300" />
